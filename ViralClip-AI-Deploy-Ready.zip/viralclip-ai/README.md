# ViralClip AI — ChatGPT App starter

A deployable starter for a video highlight extraction service connected to ChatGPT through the Apps SDK / MCP. It supports direct video uploads and public video URLs, transcript-based highlight selection, FFmpeg MP4 rendering, SRT subtitle files, and generated titles/captions/hashtags.

## Important reality checks

- This is source code, not an already-hosted or installed ChatGPT app. You must deploy it to a public HTTPS host and connect its `/mcp` endpoint in ChatGPT.
- ChatGPT app availability and custom MCP write permissions depend on the ChatGPT plan/workspace and current developer-mode availability.
- YouTube URL downloading depends on YouTube's terms, regional availability, and whether the video is publicly downloadable. This does not bypass DRM, private videos, login walls, or access controls.
- Use only videos you own or have permission to edit and republish. A highlight score is an AI estimate, not a guarantee of virality.
- The included subtitle output is a basic sentence-timed SRT fallback. For precise word-level captions and burned-in styled captions, add a timestamp-capable transcription/alignment service and FFmpeg subtitle styling.

## Requirements

- Node.js 22+
- FFmpeg + ffprobe
- yt-dlp (for public URL sources)
- OpenAI API key with API billing enabled

## Run locally

```bash
cp .env.example .env
# Set OPENAI_API_KEY and PUBLIC_BASE_URL
npm install
npm run dev
```

Open `http://localhost:8787` to upload a video. The page returns an `assetId`.

For a URL:
- Connect the MCP endpoint at `https://YOUR-HOST/mcp` in ChatGPT.
- Ask: `Create 5 clips from https://... in English, 20 to 45 seconds, 9:16.`
For an upload:
- Upload at `https://YOUR-HOST/`.
- Ask: `Create clips from assetId YOUR-ASSET-ID, 5 clips, English, 9:16.`

## MCP tools

- `create_video_clips`: starts an asynchronous job from exactly one source URL or uploaded asset ID.
- `get_video_job_status`: returns status and completed clip download URLs, captions, hashtags, and timestamps.
- `list_uploaded_videos`: points to the upload page.

## Connect to ChatGPT

1. Deploy this service to a persistent container host with HTTPS and persistent disk.
2. Set `PUBLIC_BASE_URL` to the deployed origin.
3. Configure `OPENAI_API_KEY` as a server secret; never expose it in browser code or ChatGPT messages.
4. In ChatGPT, enable developer mode / custom app creation if available to your account.
5. Add a custom MCP server using `https://YOUR-HOST/mcp`.
6. Test upload, URL processing, status polling, and clip downloads.
7. For public distribution, complete the current app review, privacy policy, domain verification, and security requirements.

Current OpenAI references:
- Apps SDK overview: https://developers.openai.com/apps-sdk/
- MCP server guide: https://developers.openai.com/plugins/build/mcp-server
- MCP app quickstart: https://developers.openai.com/plugins/build/app-quickstart
- Audio transcription: https://developers.openai.com/api/docs/guides/speech-to-text

## Production hardening before public launch

- Add user authentication/OAuth and per-user job ownership.
- Add rate limits, quotas, billing, abuse detection, upload scanning, and retention/deletion controls.
- Store job state in a durable database/queue (Redis + BullMQ or equivalent); current in-memory job state resets on restart.
- Use object storage (S3-compatible) for source and output media.
- Restrict URL fetching to supported providers and defend against SSRF; validate domains and resolved IPs.
- Add job cleanup and signed, expiring download links.
- Use a proper timestamped transcript schema; current SRT is an approximate sentence-level subtitle fallback.
- Implement cancellation, retries, observability, and worker isolation.


## Deploy on Render (recommended guided path)

1. Extract this ZIP on your computer.
2. Create a GitHub repository and upload the contents of the `viralclip-ai` folder (the files inside it, not the outer folder).
3. In Render, choose **New → Blueprint**, connect that GitHub repository, and let Render read `render.yaml`.
4. Render will create a Docker web service and a 10 GB persistent disk mounted at `/app/data`. The disk-backed plan is paid; Render's free filesystem is ephemeral and is not suitable for keeping uploaded videos and outputs across restarts.
5. In the Render service Environment page, add `OPENAI_API_KEY` with your own API key. Never put the key in browser code, GitHub, or a ChatGPT message.
6. Deploy. When the service is live, copy its public HTTPS URL. The MCP endpoint is that URL plus `/mcp`, for example `https://your-service.onrender.com/mcp`.
7. In ChatGPT web, open **Plugins → + → Add custom MCP server** (or the available custom app creation flow), paste the HTTPS `/mcp` endpoint, choose no authentication only for a private test if the UI permits it, review the warning, and create the connection. For a public service, add authentication before sharing it.
8. Inspect the discovered tools. You should see `create_video_clips`, `get_video_job_status`, and `list_uploaded_videos`. If not, check `https://YOUR-SERVICE/health` and Render logs, then refresh/recreate the MCP connection.
9. Open a new ChatGPT chat, select/mention ViralClip AI, and ask it to process a public video URL you own or are licensed to use.

Note: Render's persistent disk requires a paid service plan. API usage is billed separately by OpenAI. Add authentication, user isolation, rate limits, quotas, upload limits, and signed downloads before public release.
