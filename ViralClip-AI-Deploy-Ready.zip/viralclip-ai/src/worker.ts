import "dotenv/config";
import fs from "node:fs";
import path from "node:path";
import crypto from "node:crypto";
import { spawn } from "node:child_process";
import OpenAI from "openai";

const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
const root = path.resolve(process.env.JOB_DIR || "./data");
const uploads = path.join(root, "uploads");
const workDir = path.join(root, "work");
const outputs = path.join(root, "outputs");
for (const d of [uploads, workDir, outputs]) fs.mkdirSync(d, { recursive: true });

type Clip = { index: number; start: number; end: number; duration: number; title: string; caption: string; hashtags: string[]; transcript: string; downloadPath: string; subtitlePath: string };
type Job = { id: string; status: "queued"|"downloading"|"transcribing"|"selecting"|"rendering"|"completed"|"failed"; progress: number; message: string; createdAt: string; error?: string; clips?: Clip[] };
const jobs = new Map<string, Job>();
const configs = new Map<string, any>();

export function createJob(config: any): Job {
  const job: Job = { id: crypto.randomUUID(), status: "queued", progress: 0, message: "Queued", createdAt: new Date().toISOString() };
  jobs.set(job.id, job); configs.set(job.id, config); return job;
}
export function getJob(id: string) { return jobs.get(id); }
export function listClips(id: string) { return jobs.get(id)?.clips || []; }

function run(cmd: string, args: string[], cwd?: string): Promise<void> {
  return new Promise((resolve, reject) => {
    const p = spawn(cmd, args, { cwd, stdio: ["ignore", "pipe", "pipe"] });
    let err = ""; p.stderr.on("data", d => err += d.toString());
    p.on("error", reject); p.on("close", code => code === 0 ? resolve() : reject(new Error(`${cmd} failed: ${err.slice(-2500)}`)));
  });
}
async function transcribe(audioPath: string): Promise<any> {
  // OpenAI file transcription has a 25 MB upload limit; split larger audio into 10-minute chunks.
  const stat = fs.statSync(audioPath);
  const chunks: string[] = [];
  if (stat.size <= 24 * 1024 * 1024) chunks.push(audioPath);
  else {
    const durationText = await capture("ffprobe", ["-v","error","-show_entries","format=duration","-of","default=noprint_wrappers=1:nokey=1",audioPath]);
    const duration = Number(durationText);
    for (let start=0, i=0; start<duration; start+=600, i++) {
      const chunk = `${audioPath}.${i}.mp3`;
      await run("ffmpeg", ["-y","-ss",String(start),"-i",audioPath,"-t","600","-vn","-ac","1","-b:a","64k",chunk]);
      chunks.push(chunk);
    }
  }
  const all: any[] = []; let offset = 0;
  for (const chunk of chunks) {
    const result = await openai.audio.transcriptions.create({
      file: fs.createReadStream(chunk), model: process.env.OPENAI_TRANSCRIBE_MODEL || "gpt-transcribe",
      response_format: "verbose_json"
    } as any);
    const duration = Number((result as any).duration || 0);
    all.push({ text: result.text, offset, duration });
    offset += duration;
    if (chunk !== audioPath) fs.unlinkSync(chunk);
  }
  return all;
}
function capture(cmd: string, args: string[]): Promise<string> {
  return new Promise((resolve,reject) => {
    const p=spawn(cmd,args); let out="",err="";
    p.stdout.on("data",d=>out+=d.toString()); p.stderr.on("data",d=>err+=d.toString());
    p.on("error",reject); p.on("close",c=>c===0?resolve(out.trim()):reject(new Error(err)));
  });
}
async function selectHighlights(transcripts: any[], config: any, duration: number): Promise<any[]> {
  const transcriptText = transcripts.map(t => `[${Math.round(t.offset)}s] ${t.text}`).join("\n").slice(0, 90000);
  const prompt = `You are an expert short-form video editor. Find ${config.clipCount} self-contained, engaging highlight moments in this transcript. Prefer surprising, funny, emotional, useful, opinionated or high-energy moments with a strong hook and payoff. Do not claim actual virality or fame; estimate highlight potential from content only. Each clip must be ${config.minSeconds}-${config.maxSeconds} seconds, fit within ${duration} seconds, and avoid overlap where possible. Return ONLY JSON: {"clips":[{"start":number,"end":number,"title":string,"caption":string,"hashtags":[string],"reason":string}]}. Use seconds from the start of the full video. Captions should be short and natural. Language preference: ${config.language}. Transcript:\n${transcriptText}`;
  const response = await openai.responses.create({
    model: process.env.OPENAI_TEXT_MODEL || "gpt-4.1-mini",
    input: prompt
  });
  const text = response.output_text || "";
  const json = JSON.parse(text.slice(text.indexOf("{"), text.lastIndexOf("}")+1));
  return (json.clips || []).filter((c:any) => Number.isFinite(c.start) && Number.isFinite(c.end) &&
    c.end > c.start && c.start >= 0 && c.end <= duration + 1)
    .slice(0, config.clipCount);
}
async function writeSrt(transcripts: any[], start: number, end: number, out: string) {
  // Transcript text is used as a readable, sentence-level subtitle fallback.
  const lines = transcripts.map(t => t.text).join(" ").match(/[^.!?؟]+[.!?؟]?/g) || [];
  const selected = lines.map((s:string)=>s.trim()).filter(Boolean);
  const span = Math.max(1, end-start);
  const block = selected.slice(0, 80).map((s:string,i:number) => {
    const a = start + span*i/Math.max(1,selected.length), b = start + span*(i+1)/Math.max(1,selected.length);
    const fmt=(n:number)=>{const ms=Math.floor((n%1)*1000);const sec=Math.floor(n)%60;const min=Math.floor(n/60)%60;const hr=Math.floor(n/3600);return `${String(hr).padStart(2,"0")}:${String(min).padStart(2,"0")}:${String(sec).padStart(2,"0")},${String(ms).padStart(3,"0")}`;};
    return `${i+1}\n${fmt(a-start)} --> ${fmt(b-start)}\n${s}`;
  }).join("\n\n");
  fs.writeFileSync(out, block);
}
export async function startProcessing(id: string) {
  const job = jobs.get(id); const cfg = configs.get(id); if (!job || !cfg) return;
  const dir = path.join(workDir,id); fs.mkdirSync(dir,{recursive:true});
  try {
    job.status="downloading"; job.progress=5; job.message="Preparing source video";
    let video = "";
    if (cfg.assetId) {
      const found = fs.readdirSync(uploads).find(f => f.startsWith(cfg.assetId));
      if (!found) throw new Error("Uploaded asset not found. Upload it again and use the new assetId.");
      video = path.join(uploads,found);
    } else {
      // yt-dlp respects source platform access controls; private/DRM/protected streams are not bypassed.
      video = path.join(dir,"source.mp4");
      await run("yt-dlp", ["--no-playlist","--merge-output-format","mp4","-f","bv*+ba/b","-o",video,cfg.sourceUrl]);
      if (!fs.existsSync(video)) {
        const files=fs.readdirSync(dir).filter(f=>f.startsWith("source."));
        if (!files.length) throw new Error("Could not download video. Check that the URL is public and downloadable.");
        video=path.join(dir,files[0]);
      }
    }
    job.status="transcribing"; job.progress=20; job.message="Extracting audio and transcribing";
    const audio=path.join(dir,"audio.mp3");
    await run("ffmpeg",["-y","-i",video,"-vn","-ac","1","-b:a","96k",audio]);
    const duration=Number(await capture("ffprobe",["-v","error","-show_entries","format=duration","-of","default=noprint_wrappers=1:nokey=1",video]));
    if (!duration || !Number.isFinite(duration)) throw new Error("Could not read video duration.");
    const transcripts=await transcribe(audio);
    job.status="selecting"; job.progress=55; job.message="Finding engaging moments";
    const highlights=await selectHighlights(transcripts,cfg,duration);
    if (!highlights.length) throw new Error("No suitable highlight segments were found in the transcript.");
    job.status="rendering"; job.progress=65; job.message="Rendering separate MP4 clips";
    const clips: Clip[]=[];
    for (let i=0;i<highlights.length;i++) {
      const h=highlights[i], n=i+1, filename=`${id}-clip-${n}.mp4`;
      const out=path.join(outputs,filename), srt=path.join(outputs,`${id}-clip-${n}.srt`);
      const start=Math.max(0,Number(h.start)), end=Math.min(duration,Number(h.end));
      const vf=cfg.aspectRatio==="9:16" ? "scale=1080:1920:force_original_aspect_ratio=decrease,pad=1080:1920:(ow-iw)/2:(oh-ih)/2" :
        cfg.aspectRatio==="1:1" ? "scale=1080:1080:force_original_aspect_ratio=decrease,pad=1080:1080:(ow-iw)/2:(oh-ih)/2" :
        "scale=1920:1080:force_original_aspect_ratio=decrease,pad=1920:1080:(ow-iw)/2:(oh-ih)/2";
      await run("ffmpeg",["-y","-ss",String(start),"-i",video,"-t",String(end-start),"-vf",vf,"-c:v","libx264","-preset","veryfast","-crf","23","-c:a","aac","-movflags","+faststart",out]);
      const text=transcripts.map(t=>t.text).join(" ");
      await writeSrt([{text}],start,end,srt);
      clips.push({index:n,start,end,duration:end-start,title:String(h.title||`Highlight ${n}`),caption:String(h.caption||""),hashtags:Array.isArray(h.hashtags)?h.hashtags:[],transcript:text.slice(0,1500),downloadPath:`/files/${filename}`,subtitlePath:`/files/${id}-clip-${n}.srt`});
      job.progress=65+Math.round(30*(i+1)/highlights.length);
    }
    job.clips=clips; job.status="completed"; job.progress=100; job.message=`Created ${clips.length} clips`;
  } catch(e:any) {
    job.status="failed"; job.error=e?.message || "Unknown processing error"; job.message="Processing failed";
  }
}
