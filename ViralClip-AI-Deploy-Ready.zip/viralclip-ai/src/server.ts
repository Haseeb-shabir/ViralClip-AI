import "dotenv/config";
import express from "express";
import cors from "cors";
import multer from "multer";
import path from "node:path";
import fs from "node:fs";
import crypto from "node:crypto";
import { z } from "zod";
import { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import { StreamableHTTPServerTransport } from "@modelcontextprotocol/sdk/server/streamableHttp.js";
import { isInitializeRequest } from "@modelcontextprotocol/sdk/types.js";
import { startProcessing, getJob, createJob, listClips } from "./worker.js";

const app = express();
const port = Number(process.env.PORT || 8787);
const base = process.env.PUBLIC_BASE_URL || process.env.RENDER_EXTERNAL_URL || `http://localhost:${port}`;
const dataDir = path.resolve(process.env.JOB_DIR || "./data");
const uploadDir = path.join(dataDir, "uploads");
fs.mkdirSync(uploadDir, { recursive: true });

app.use(cors({ origin: true, exposedHeaders: ["Mcp-Session-Id"] }));
app.use(express.json({ limit: "2mb" }));
app.use("/files", express.static(path.join(dataDir, "outputs"), {
  setHeaders(res) { res.setHeader("Content-Disposition", "attachment"); }
}));
app.use(express.static("public"));

const upload = multer({
  dest: uploadDir,
  limits: { fileSize: Number(process.env.MAX_UPLOAD_GB || 2) * 1024 * 1024 * 1024 },
  fileFilter(_req, file, cb) {
    const ok = /video\/(mp4|quicktime|webm|x-matroska|mpeg)/.test(file.mimetype) ||
      /\.(mp4|mov|webm|mkv|mpeg)$/i.test(file.originalname);
    cb(ok ? null : new Error("Upload a supported video file (MP4, MOV, WEBM, MKV)."), ok);
  }
});

app.post("/upload", upload.single("video"), (req, res) => {
  if (!req.file) return res.status(400).json({ error: "No video file received." });
  const assetId = crypto.randomUUID();
  const target = path.join(uploadDir, `${assetId}${path.extname(req.file.originalname) || ".mp4"}`);
  fs.renameSync(req.file.path, target);
  res.json({ assetId, filename: req.file.originalname, message: "Upload complete. Submit this assetId to ViralClip AI in ChatGPT." });
});

app.get("/health", (_req, res) => res.json({ ok: true, service: "ViralClip AI", version: "1.0.0" }));

const sessions = new Map<string, StreamableHTTPServerTransport>();
function makeMcpServer() {
  const server = new McpServer({ name: "viralclip-ai", version: "1.0.0" });

  server.registerTool("create_video_clips", {
    title: "Create viral video clips",
    description: "Analyze a video URL or previously uploaded asset, detect engaging moments, create separate MP4 clips, subtitles, captions and hashtags. Only process content the user owns or is authorized to edit.",
    inputSchema: {
      source_url: z.string().url().optional().describe("Public video URL, for example a YouTube URL."),
      asset_id: z.string().uuid().optional().describe("assetId returned by the ViralClip AI upload page."),
      clip_count: z.number().int().min(1).max(20).default(5),
      min_seconds: z.number().int().min(10).max(180).default(20),
      max_seconds: z.number().int().min(15).max(300).default(60),
      language: z.enum(["English", "Urdu", "Auto"]).default("Auto"),
      aspect_ratio: z.enum(["9:16", "16:9", "1:1"]).default("9:16")
    }
  }, async (args) => {
    if ((!args.source_url && !args.asset_id) || (args.source_url && args.asset_id)) {
      return { content: [{ type: "text", text: "Provide exactly one of source_url or asset_id." }], isError: true };
    }
    if (args.source_url && !/^https?:\/\//i.test(args.source_url)) {
      return { content: [{ type: "text", text: "Only HTTP(S) video URLs are accepted." }], isError: true };
    }
    const job = createJob({
      sourceUrl: args.source_url,
      assetId: args.asset_id,
      clipCount: args.clip_count,
      minSeconds: args.min_seconds,
      maxSeconds: args.max_seconds,
      language: args.language,
      aspectRatio: args.aspect_ratio
    });
    startProcessing(job.id).catch(console.error);
    return { content: [{ type: "text", text: JSON.stringify({
      jobId: job.id, status: "queued",
      message: "Video accepted. Processing runs in the background. Use get_video_job_status with this jobId to retrieve clips."
    }) }] };
  });

  server.registerTool("get_video_job_status", {
    title: "Get video clip job status",
    description: "Check processing progress and retrieve finished clip download links, captions and timestamps.",
    inputSchema: { job_id: z.string().uuid() }
  }, async ({ job_id }) => {
    const job = getJob(job_id);
    if (!job) return { content: [{ type: "text", text: "Job not found." }], isError: true };
    const clips = listClips(job_id).map(c => ({
      ...c, download_url: `${base}${c.downloadPath}`
    }));
    return { content: [{ type: "text", text: JSON.stringify({ ...job, clips }) }] };
  });

  server.registerTool("list_uploaded_videos", {
    title: "List uploaded videos",
    description: "Explain how to upload a video and return the upload page address.",
    inputSchema: {}
  }, async () => ({ content: [{ type: "text", text: `Upload a video at ${base}/ and then pass the returned assetId to create_video_clips.` }] }));

  return server;
}

app.post("/mcp", async (req, res) => {
  const sessionId = req.headers["mcp-session-id"] as string | undefined;
  let transport = sessionId ? sessions.get(sessionId) : undefined;
  if (!transport) {
    if (!isInitializeRequest(req.body)) return res.status(400).json({ error: "Missing or invalid MCP session. Initialize first." });
    transport = new StreamableHTTPServerTransport({
      sessionIdGenerator: () => crypto.randomUUID(),
      onsessioninitialized: id => sessions.set(id, transport!)
    });
    transport.onclose = () => {
      const id = transport?.sessionId;
      if (id) sessions.delete(id);
    };
    const server = makeMcpServer();
    await server.connect(transport);
  }
  await transport.handleRequest(req, res, req.body);
});
app.get("/mcp", async (_req, res) => res.status(405).send("MCP endpoint supports POST."));
app.delete("/mcp", async (req, res) => {
  const id = req.headers["mcp-session-id"] as string;
  const transport = sessions.get(id);
  if (transport) await transport.close();
  res.status(200).end();
});

app.listen(port, () => console.log(`ViralClip AI listening on ${port}`));
