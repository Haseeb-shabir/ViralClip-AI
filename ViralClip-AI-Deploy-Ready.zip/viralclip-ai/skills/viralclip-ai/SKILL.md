---
name: viralclip-ai
description: Use ViralClip AI to analyze a video URL or uploaded video, select engaging moments, create short clips, and generate captions and hashtags.
---

# ViralClip AI

Use this workflow when the user wants short clips extracted from a video.

## Supported inputs
- A public video URL, such as a YouTube URL, provided the source is legally accessible and downloadable.
- A video uploaded through the ViralClip AI web uploader. The uploader returns an `assetId`.

## Workflow
1. Ask for the video URL or an uploaded `assetId` if it is not already provided.
2. Ask only for missing preferences that materially affect the result. Defaults: 5 clips, 20–60 seconds each, English/automatic language, vertical 9:16.
3. Call the connected ViralClip AI MCP tool `create_video_clips` with exactly one source: `source_url` OR `asset_id`.
4. Explain that processing runs asynchronously and use `get_video_job_status` with the returned `jobId` to check progress.
5. When complete, present each clip's title, start/end timestamps, caption, hashtags, and download link.
6. Never claim a clip is guaranteed to go viral. Describe highlight selection as an AI estimate of engagement potential.

## Upload instructions
If the user has a local video file, direct them to the ViralClip AI uploader configured by the app owner. They should upload the file and provide the returned `assetId` to ChatGPT. Do not claim the upload is complete unless an actual upload response is available.

## Safety and rights
Only process videos the user owns or is authorized to edit and republish. Do not bypass DRM, private-video restrictions, login walls, or other access controls. If a URL cannot be accessed, ask the user to upload an authorized copy instead.
